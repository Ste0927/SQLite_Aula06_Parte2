package br.com.stefany.filadechamados;

import android.widget.ImageView;
import android.widget.TextView;

public class ChamadoViewHolder {

    TextView descricaoChamadoTextView;
    TextView dataAberturaChamadoNaFilaTextView;
    TextView dataFechamentoChamadoNaFilaTextView;
    TextView statusChamadoNaFilaTextView;
    ImageView filaIconImageView;
}